import datetime
import pytz
x = datetime.datetime.now(pytz.utc)

print("Time is ", x.strftime("%a %b %d %Y:%X GMT%z (%Z)"))

